<template>
    <div>
       SearchContainer
    </div>
</template>
           
<script>
export default{
             
}
</script>
<style scoped>
          
</style>
